%% Setup
clc
clear all
close all
% Number of poles
np = 4;
% Recording Outputs
diary('TF_Outputs')
diary off

%%

