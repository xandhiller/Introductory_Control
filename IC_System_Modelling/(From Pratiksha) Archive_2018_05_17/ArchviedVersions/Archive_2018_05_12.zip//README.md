# **Channel 1**: #
## Y-displacement ##

# **Channel 2**: #
## Step input ##

# **Channel 3**: #
## X-displacement ##


#**Scope 3**: #
x-displacement and y motor (noisy) (3 Vpp, 1.5 DC offset) (CSV)

#**Scope 4**: #
y-displacement (3 Vpp, 1.5 DC offset) (CSV rerun)

**Scope 5**:
x-displacement (3 Vpp, 1.5 DC offset) (PNG rerun)

# **Scope 6**: #
y-displacement (3 Vpp, 1.5 DC offset) (CSV)

**Scope 7**:
y-displacement (3 Vpp, 1.5 DC offset) (PNG)

# **Scope 8**: #
x-displacement (3 Vpp, 1.5 DC offset) (CSV rerun)

**Scope 9**:
x-displacement (3 Vpp, 1.5 DC offset) (PNG rerun)
